/**
 * Repast Space class for Coupled Model
 * @author Tommy Athey
 * Aug 2017
 */
package aMFAC_REU;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;

import com.mathworks.engine.MatlabEngine;

import repast.simphony.scenario.data.Classpath;

import repast.simphony.context.DefaultContext;
import repast.simphony.context.space.grid.GridFactoryFinder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ISchedule;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.grid.Grid;
import repast.simphony.space.grid.GridBuilderParameters;
import repast.simphony.space.grid.GridPoint;
import repast.simphony.space.grid.RandomGridAdder;
import repast.simphony.space.grid.StrictBorders;
import repast.simphony.space.grid.WrapAroundBorders;
import repast.simphony.space.grid.BouncyBorders;
import repast.simphony.util.ClassPathEntry;
import repast.simphony.valueLayer.GridValueLayer;
import repast.simphony.valueLayer.ValueLayerDiffuser;

public class AMFACSpace extends DefaultContext<Object> {
	
	Grid<Object> grid;
	
	//get parameters from GUI input
	private Parameters p = RunEnvironment.getInstance().getParameters();
	private int gridWidth = (Integer) p.getValue("gridWidth");
	private int gridHeight = (Integer) p.getValue("gridHeight");
	private int endTick = (Integer) p.getValue("endTick");
	int initialFibroblastCount = (Integer) p.getValue("initialFibroblastCount");
	
	//arraylist that will hold all fibroblasts in the world (useful for iteration)
	private ArrayList<Fibroblast> fibroblasts = new ArrayList<Fibroblast>();

	//create Grid value layers
	private GridValueLayer collagen;
	private GridValueLayer TGFb_conc;
	private GridValueLayer LatentTGFb;
	private GridValueLayer IL6;
	private GridValueLayer IL1;
	private GridValueLayer TNFa;
	private GridValueLayer LatentTGFb_conc;
	private GridValueLayer IL6_conc;
	private GridValueLayer IL1_conc;
	private GridValueLayer TNFa_conc;
	
	//initial matlab engine
	private MatlabEngine eng;
	
	//define parameters for all of the coupling equations
	private double Kd_IL6 = 462000; //pg/mL
	private double Kd_IL1 = 8750; //pg/mL
	private double Kd_TNFa = 323; //pg/mL
	private double Kd_TGFb = 700; //pg/mL
	
	private double kgen_latentTGFb = 530000; //pg/mL*hr
	private double kconv_latentTGFb = 2.37e-5; //pg/hr
	//private double kconv_latentTGFb = 0.0; //pg/hr
	private double kdeg_latentTGFb = 0.0096; //hr
	private double kact_latentTGFb = 0.045; //4.5%
	private double kgen_IL1 = 4847; //pg/hr
	private double kdeg_IL1 = 0.2773; //hr
	private double kgen_IL6 = 256000; //pg/hr
	private double kconv_IL6 = 0.0248; //pg/hr
	//private double kconv_IL6 = 0.0;
	private double kdeg_IL6 = 0.2773; //hr
	private double kgen_TNFa = 895.4; //pg/hr
	private double kdeg_TNFa = 1.386; //hr
	
	private double kdep_collagen = 0.0056; 
	private double kdeg_collagen = 0.0035;

	private double volume_media = 3.125e-7; 
	private double volume_cells = 1e-9;
	
	private double[] TGFBweights;
	private double[] IL1weights;
	private double[] IL6weights;
	private double[] TNFaweights;
	
	private int cellsPerGrid = 1;

	double[] initialNet = new double[91];


		/**
	 * Create all fields necessary for this class
	 */
	public AMFACSpace() {
		super("AMFACSpace");

		// Define the Grid Space - note bouncy borders is used here, false refers to multiple occupancy rule
		grid = GridFactoryFinder.createGridFactory(null).createGrid("grid", this,
				new GridBuilderParameters<Object>(new BouncyBorders(), new RandomGridAdder<Object>(), false,
						gridWidth, gridHeight));

		
		// Build all GridValueLayers
		//initialize collagen layer at 4% area fraction, all others at zero
		collagen = new GridValueLayer("collagen", 0.04, false, gridWidth, gridHeight);
		this.addValueLayer(collagen);
		TGFb_conc = new GridValueLayer("TGFb_conc", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(TGFb_conc);
		LatentTGFb = new GridValueLayer("LatentTGFb", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(LatentTGFb);
		IL6 = new GridValueLayer("IL6", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(IL6);
		IL1 = new GridValueLayer("IL1", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(IL1);
		TNFa = new GridValueLayer("TNFa", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(TNFa);
		LatentTGFb_conc = new GridValueLayer("LatentTGFb_conc", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(LatentTGFb_conc);
		IL6_conc = new GridValueLayer("IL6_conc", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(IL6_conc);
		IL1_conc = new GridValueLayer("IL1_conc", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(IL1_conc);
		TNFa_conc = new GridValueLayer("TNFa_conc", 0.0, false, gridWidth, gridHeight);
		this.addValueLayer(TNFa_conc);

		
	}
	
	
	@ScheduledMethod(start = 0, priority = 1)
	public void initialize() {
		loadMatlab();
		initializeFibroblasts();
		
		ISchedule schedule = RunEnvironment.getInstance().getCurrentSchedule();
		double tick = schedule.getTickCount();
		writeOutputData(tick); 
	}
	
	
	@ScheduledMethod(start = 1, interval = 1, priority = 2)
	public void goFirst() {
		ISchedule schedule = RunEnvironment.getInstance().getCurrentSchedule();
		double tick = schedule.getTickCount();
		//start running network after value layers have reached steady state
		initializeNetworkState();
		
		if (tick > 20){
			runNetworkModel();
		}
		updateValueLayers();
		writeOutputData(tick);
		//System.out.println("Second");
	}
	
		
	public void loadMatlab() {
		//start the matlab connection
		try {
			eng = MatlabEngine.startMatlab();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//System.out.println("Load Matlab");
	}
	
	public void initializeFibroblasts() {	
		//add fibroblasts
		Fibroblast fibroblast;
		for (int i = 0; i < initialFibroblastCount; i++) {
			fibroblast = new Fibroblast(this, cellsPerGrid);
			this.add(fibroblast);
			fibroblasts.add(fibroblast);
		}
		
		//System.out.println("Initialize Fibroblasts");
	}
	
	public void initializeNetworkState() {
		// load the mat file only once
		try {
			eng.eval("load network.mat");
/*			eng.eval("load initialNet.mat");
			initialNet = eng.getVariable("initialNet");
			
			for (Fibroblast f: fibroblasts) {
				f.setNetworkState(initialNet);
			}*/

		} catch (Exception e) {
			System.out.println(e);
		}
		
		//System.out.println("Initialize Network State");
		
	}
	

	public void writeOutputData(double tick) {
		//collagen
		
		//String fileName = "C:\\Users\\smr2we\\Documents\\collagen.csv";
		String fileName = ".\\Results\\metadata.txt";
		String delim = ",";
		String newline = "\n";
		FileWriter fileWriter;
		
		if (tick == 1){

		try {
			fileWriter = new FileWriter(fileName, true);
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
			String string = dateFormat.format(new Date());
			fileWriter.append(string);
			fileWriter.append(newline);
			
			Parameters p = RunEnvironment.getInstance().getParameters();
			int gridWidth = (Integer) p.getValue("gridWidth");
			int gridHeight = (Integer) p.getValue("gridHeight");
			int endTick = (Integer) p.getValue("endTick");
			int initialFibroblastCount = (Integer) p.getValue("initialFibroblastCount");
			
			fileWriter.append("Grid Width: ");
			fileWriter.append(Double.toString(gridWidth));
			fileWriter.append(newline);
			
			fileWriter.append("Grid Height: ");
			fileWriter.append(Double.toString(gridHeight));
			fileWriter.append(newline);
			
			fileWriter.append("Initial Fibroblast Count: ");
			fileWriter.append(Double.toString(initialFibroblastCount));
			fileWriter.append(newline);
			
			fileWriter.append("End Time: ");
			fileWriter.append(Double.toString(endTick));
			fileWriter.append(newline);
			
			fileWriter.append("Kd_IL6 ");
			fileWriter.append(Double.toString(Kd_IL6));
			fileWriter.append(newline);
			
			fileWriter.append("Kd_IL1 ");
			fileWriter.append(Double.toString(Kd_IL1));
			fileWriter.append(newline);
			
			fileWriter.append("Kd_TNFa ");
			fileWriter.append(Double.toString(Kd_TNFa));
			fileWriter.append(newline);
			
			fileWriter.append("Kd_TGFb ");
			fileWriter.append(Double.toString(Kd_TGFb));
			fileWriter.append(newline);
			
			fileWriter.append("kgen_latentTGFb ");
			fileWriter.append(Double.toString(kgen_latentTGFb));
			fileWriter.append(newline);
			
			fileWriter.append("kconv_latentTGFb ");
			fileWriter.append(Double.toString(kconv_latentTGFb));
			fileWriter.append(newline);
			
			fileWriter.append("kdeg_latentTGFb ");
			fileWriter.append(Double.toString(kdeg_latentTGFb));
			fileWriter.append(newline);

			fileWriter.append("kact_latentTGFb ");
			fileWriter.append(Double.toString(kact_latentTGFb));
			fileWriter.append(newline);

			fileWriter.append("kgen_IL1 ");
			fileWriter.append(Double.toString(kgen_IL1));
			fileWriter.append(newline);
			
			fileWriter.append("kdeg_IL1 ");
			fileWriter.append(Double.toString(kdeg_IL1));
			fileWriter.append(newline);
			
			fileWriter.append("kgen_IL6 ");
			fileWriter.append(Double.toString(kgen_IL6));
			fileWriter.append(newline);
	
			fileWriter.append("kconv_IL6 ");
			fileWriter.append(Double.toString(kconv_IL6));
			fileWriter.append(newline);
			
			fileWriter.append("kdeg_IL6 ");
			fileWriter.append(Double.toString(kdeg_IL6));
			fileWriter.append(newline);

			fileWriter.append("kgen_TNFa ");
			fileWriter.append(Double.toString(kgen_TNFa));
			fileWriter.append(newline);

			fileWriter.append("kdeg_TNFa ");
			fileWriter.append(Double.toString(kdeg_TNFa));
			fileWriter.append(newline);

			fileWriter.append("kdep_collagen ");
			fileWriter.append(Double.toString(kdep_collagen));
			fileWriter.append(newline);
			
			fileWriter.append("kdeg_collagen ");
			fileWriter.append(Double.toString(kdeg_collagen));
			fileWriter.append(newline);
					

			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		}
		
		
		//collagen
		
		//String fileName = "C:\\Users\\smr2we\\Documents\\collagen.csv";
		fileName = ".\\Results\\collagen.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(collagen.get(x,y)));
					//if not at the end
					if (!(x+1 == gridWidth && y+1 == gridHeight)) {
						fileWriter.append(delim);
					}
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
			
		//tgfb
		fileName = ".\\Results\\TGFb_conc.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(TGFb_conc.get(x,y))); //index 0 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//latent tgfb
		fileName = ".\\Results\\LatentTGFb.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(LatentTGFb.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//latent tgfb concentration
		fileName = ".\\Results\\LatentTGFb_conc.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(LatentTGFb_conc.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//il6
		fileName = ".\\Results\\IL6.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(IL6.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//il6 concentration
		fileName = ".\\Results\\IL6_conc.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(IL6_conc.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//TNFa
		fileName = ".\\Results\\TNFa.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(TNFa.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//TNFa concentration
		fileName = ".\\Results\\TNFa_conc.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(TNFa_conc.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//IL1-B
		fileName = ".\\Results\\IL1.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(IL1.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		//IL1-B concentration
		fileName = ".\\Results\\IL1_conc.csv";
		try {
			fileWriter = new FileWriter(fileName, true);
			for (int y = 0; y < gridHeight; y++) {
				for (int x = 0; x < gridWidth; x++) {
					fileWriter.append(Double.toString(IL1_conc.get(x,y))); //index 1 is hardcoded in here
					fileWriter.append(delim);
				}
			}
			fileWriter.append(newline);
			try {
				fileWriter.flush();
				fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter !!!");
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}

		//TGFb weights
		
		
			fileName = ".\\Results\\TGFb_weights.csv";
			
			try {
				fileWriter = new FileWriter(fileName, true);
				for (int y = 0; y < gridHeight; y++) {
					for (int x = 0; x < gridWidth; x++) {
						fileWriter.append(Double.toString(TGFb_conc.get(x,y)/(Kd_TGFb + TGFb_conc.get(x,y)))); //index 1 is hardcoded in here
						fileWriter.append(delim);
					}
				}
				fileWriter.append(newline);
				try {
					fileWriter.flush();
					fileWriter.close();
				} catch (IOException e) {
					System.out.println("Error while flushing/closing fileWriter !!!");
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				System.out.println("Error in CsvFileWriter !!!");
				e.printStackTrace();
			}
		
	
		//IL-1 weights
		
			fileName = ".\\Results\\IL1_weights.csv";
			
			try {
				fileWriter = new FileWriter(fileName, true);
				for (int y = 0; y < gridHeight; y++) {
					for (int x = 0; x < gridWidth; x++) {
						fileWriter.append(Double.toString(IL1_conc.get(x,y)/(Kd_IL1 + IL1_conc.get(x,y)))); //index 1 is hardcoded in here
						fileWriter.append(delim);
					}
				}
				fileWriter.append(newline);
				try {
					fileWriter.flush();
					fileWriter.close();
				} catch (IOException e) {
					System.out.println("Error while flushing/closing fileWriter !!!");
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				System.out.println("Error in CsvFileWriter !!!");
				e.printStackTrace();
			}
		
		
		//IL6 weights
		

			fileName = ".\\Results\\IL6_weights.csv";
			
			try {
				fileWriter = new FileWriter(fileName, true);
				for (int y = 0; y < gridHeight; y++) {
					for (int x = 0; x < gridWidth; x++) {
						fileWriter.append(Double.toString(IL6_conc.get(x,y)/(Kd_IL6 + IL6_conc.get(x,y)))); //index 1 is hardcoded in here
						fileWriter.append(delim);
					}
				}
				fileWriter.append(newline);
				try {
					fileWriter.flush();
					fileWriter.close();
				} catch (IOException e) {
					System.out.println("Error while flushing/closing fileWriter !!!");
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				System.out.println("Error in CsvFileWriter !!!");
				e.printStackTrace();
			}
		
		
		//TNFa weights
		
			fileName = ".\\Results\\TNFa_weights.csv";
			
			try {
				fileWriter = new FileWriter(fileName, true);
				for (int y = 0; y < gridHeight; y++) {
					for (int x = 0; x < gridWidth; x++) {
						fileWriter.append(Double.toString(TNFa_conc.get(x,y)/(Kd_TNFa + TNFa_conc.get(x,y)))); //index 1 is hardcoded in here
						fileWriter.append(delim);
					}
				}
				fileWriter.append(newline);
				try {
					fileWriter.flush();
					fileWriter.close();
				} catch (IOException e) {
					System.out.println("Error while flushing/closing fileWriter !!!");
					e.printStackTrace();
				}
				
			} catch (Exception e) {
				System.out.println("Error in CsvFileWriter !!!");
				e.printStackTrace();
			}
		
	
		//final network state
				
				if (tick == endTick){
					fileName = ".\\Results\\SteadyStateNetwork.csv";
					
					try {
						fileWriter = new FileWriter(fileName, true);
						for (int y = 0; y < gridHeight; y++) {
							for (int x = 0; x < gridWidth; x++) {
								for( Object object: grid.getObjectsAt(x,y)) {
									
									Fibroblast f = (Fibroblast)object;
									double[] states = f.getNetworkState();
								
									for (int i = 0; i < states.length; i++){
										fileWriter.append(Double.toString(states[i]));
										fileWriter.append(delim);
									}

								}
								fileWriter.append(newline);
						}
						}

						try {
							fileWriter.flush();
							fileWriter.close();
						} catch (IOException e) {
							System.out.println("Error while flushing/closing fileWriter !!!");
							e.printStackTrace();
						}
						
					} catch (Exception e) {
						System.out.println("Error in CsvFileWriter !!!");
						e.printStackTrace();
					}
				}
				
				//network state of all fibroblasts
				if (fibroblasts.size() != 0) {
				
				for (int i=0; i < fibroblasts.size(); i++) {

					fileName = ".\\Results\\Fibroblast" + Integer.toString(i) + ".csv";
					//System.out.println(fileName);
				
					
					try {
						fileWriter = new FileWriter(fileName, true);
						
						double[] networkstate = fibroblasts.get(i).getNetworkState();
						GridPoint pt = fibroblasts.get(i).getPoint();
						double y = pt.getY();
						double x = pt.getX();
						
								
						for (int j = 0; j < networkstate.length; j++){
								fileWriter.append(Double.toString(networkstate[j]));
								fileWriter.append(delim);
						}
						fileWriter.append(Double.toString(x));
						fileWriter.append(delim);
						fileWriter.append(Double.toString(y));
						fileWriter.append(delim);

						fileWriter.append(newline);
						
						try {
							fileWriter.flush();
							fileWriter.close();
						} catch (IOException e) {
							System.out.println("Error while flushing/closing fileWriter !!!");
							e.printStackTrace();
						}
						
					} catch (Exception e) {
						System.out.println("Error in CsvFileWriter !!!");
						e.printStackTrace();
					}
				}
				}
					
					
				
		//System.out.println("Write Output Data");
				
	}
	
	/**
	 * Adding new fibroblasts via mitosis is done here so the fibroblast can be cataloged in the arraylist
	 * network state of parent cell is given to daughter cell
	 * Note that it does not check if the point is full/inhabited-this should be done by objects that call addFibroblast
	 * @param pt the grid point to which the fibroblast should be added
	 */
	public void addFibroblast(GridPoint pt, double[] network) {
		Fibroblast f = new Fibroblast(this, cellsPerGrid);
		this.add(f);
		double[] initial = new double[91];
		f.setNetworkState(initial);
		//f.setNetworkState(network); //if you want daughter cells to inherit network state of the parent cell
		grid.moveTo(f, pt.getX(), pt.getY());
		fibroblasts.add(f);
	}
	
	/**
	 * remove a fibroblast from the array list and the world itself
	 * @param f
	 */
	public void removeFibroblast(Fibroblast f) {
		fibroblasts.remove(f); //will remove the first instance of this cell (assuming it does it correctly)
		this.remove(f); //remove from the context
	}
	
	
	/**
	 * Iterates through all the cells in the array list then creates a large array to pass to matlab to process all at once
	 */
	//this method gets the current network state for each fibroblast, runs the network model for one time step for that fibroblast
	//and returns its new network state. It does nothing to the value layers.
	public void runNetworkModel() {
		if (fibroblasts.size() == 0) {
			return;
		}
		
		//get every fibroblast's current network state
		
		double[][] states = new double[fibroblasts.size()][fibroblasts.get(0).getNetworkState().length];
		TGFBweights = new double[fibroblasts.size()];
		IL1weights = new double[fibroblasts.size()];
		IL6weights = new double[fibroblasts.size()];
		TNFaweights = new double[fibroblasts.size()];
		
		
		for (int i=0; i < fibroblasts.size(); i++) {
			states[i] = fibroblasts.get(i).getNetworkState();
			Fibroblast f = fibroblasts.get(i);
			GridPoint pt = f.getPoint();
			double y = pt.getY();
			double x = pt.getX();
			
			
			TGFBweights[i] = TGFb_conc.get(x,y)/(Kd_TGFb + TGFb_conc.get(x,y));
			if (TGFBweights[i] > 1) {
				TGFBweights[i] = 1;
			}
			IL1weights[i] = IL1_conc.get(x,y)/(Kd_IL1 + IL1_conc.get(x,y));
			if (IL1weights[i] > 1) {
				IL1weights[i] = 1;
			}
			IL6weights[i] = IL6_conc.get(x,y)/(Kd_IL6 + IL6_conc.get(x,y));
			if (IL6weights[i] > 1){
				IL6weights[i] = 1;
			}
			TNFaweights[i] = TNFa_conc.get(x,y)/(Kd_TNFa + TNFa_conc.get(x,y));
			if (TNFaweights[i] > 1){
				TNFaweights[i] = 1;
			}
			//System.out.println(Arrays.toString(TNFaweights));
		}
		
			
		try {

			eng.putVariable("states", states);

			eng.putVariable("TGFBweights", TGFBweights);

			eng.putVariable("IL1weights", IL1weights);

			eng.putVariable("IL6weights", IL6weights);

			eng.putVariable("TNFaweights", TNFaweights);

			//System.out.println(System.currentTimeMillis());
			eng.eval("processCellBehavior");
			//System.out.println(System.currentTimeMillis());
			
			states =  eng.getVariable("states"); //since states is a 2d array, there must be at least 2 fibroblasts

			
			GridPoint pt;
			Fibroblast f;
			
			for (int i=0; i < fibroblasts.size(); i++) {
				f = fibroblasts.get(i);
				f.setNetworkState(states[i]);	
			}
			
		} catch (Exception e) {
			System.out.println("Error in Space-processCellBehavior");
			System.out.println(e);
		}
		
		//System.out.println("Process Cell Behavior");
	}
	
	public void updateValueLayers() {
		for (int x=0; x < gridWidth; x++){
			for (int y=0; y < gridHeight; y++ ){
				
			//All exogenous deposition and degradation must occur here so that it happens at every grid space
			//generation rates are a function of x position for inflammatory layers (IL1, IL6, TNFa)
			double currentIL1 = IL1.get(x, y);
			double gradient_x = (double) (x+1) / (double) gridWidth;
			double gradient_y = (double) (y+1) / (double) gridHeight;
			//double gradient_x = 0.75;
			//double gradient_y = 0.75;
			double dIL1dt = kgen_IL1*gradient_x*volume_media - kdeg_IL1*currentIL1;
			if ((currentIL1 + dIL1dt) >= 0){
				IL1.set((currentIL1+dIL1dt), x, y);
			} else {
				IL1.set(0, x, y);
				System.out.println("Warning - IL1");
			}
			
			double currentTNFa = TNFa.get(x, y);
			double dTNFadt = kgen_TNFa*gradient_x*volume_media - kdeg_TNFa*currentTNFa;
			if ((currentTNFa + dTNFadt) >= 0){
				TNFa.set((currentTNFa+dTNFadt), x, y);
			} else {
				TNFa.set(0,  x, y);
				System.out.println("Warning - TNFa");
			}
			
			double currentIL6 = IL6.get(x, y);
			double dIL6dt = kgen_IL6*gradient_x*volume_media - kdeg_IL6*currentIL6;
			if ((currentIL6 + dIL6dt) >= 0){
				IL6.set((currentIL6+dIL6dt), x, y);
			} else {
				IL6.set(0,  x, y);
				System.out.println("Warning - IL6");
			}
			
			double currentlatentTGFb = LatentTGFb.get(x, y);
			double dlatentdt = kgen_latentTGFb*gradient_y*volume_cells - kact_latentTGFb*currentlatentTGFb - kdeg_latentTGFb*currentlatentTGFb;
			if ((currentlatentTGFb + dlatentdt) >= 0){
				LatentTGFb.set((currentlatentTGFb+dlatentdt), x, y);
			} else {
				LatentTGFb.set(0, x, y);
				System.out.println("Warning - Latent Tgfb");
			}
			
			
			double currentcollagen = collagen.get(x, y);
			double dcollagendt = kdeg_collagen*currentcollagen;
			if ((currentcollagen + dcollagendt) >= 0){
				collagen.set(currentcollagen-dcollagendt, x, y);
			} else {
				collagen.set(0,  x, y);
				System.out.println("Warning - collagen");
			}
				
			//for value layers that have a component of fibroblast deposition, deposit that component from the fibroblast here	
			for( Object object: grid.getObjectsAt(x,y)) {
				
			Fibroblast f = (Fibroblast)object;
			double[] states = f.getNetworkState();
			
			double newIL6 = IL6.get(x, y);
			double IL6_net = states[38]; //IL6 from network state of fibroblast
			double dIL6new_dt = kconv_IL6*IL6_net;
			if ((newIL6 + dIL6new_dt) >= 0){
				IL6.set(newIL6+dIL6new_dt, x, y);
			} else {
				IL6.set(0, x, y);
				System.out.println("Warning - IL6 (fibroblast)");
			}
			
			double newlatent = LatentTGFb.get(x, y);
			double latent_net = states[23]; //Latent TGFb from network state of fibroblast
			double dlatentnew_dt = kconv_latentTGFb*latent_net;
			if ((newlatent + dlatentnew_dt) >= 0){
				LatentTGFb.set(newlatent+dlatentnew_dt, x, y);
			} else {
				LatentTGFb.set(0,  x, y);
				System.out.println("Warning - latent TGFb (fibroblast)");
			}
			
			double newcollagen = collagen.get(x, y);
			double collagen_net = (states[87]+states[88])/2; //ColImRNA and ColIIImRNA from network state of fibroblast
			double dcollagennew_dt = kdep_collagen*collagen_net;
			if ((newcollagen + dcollagennew_dt) >= 0){
				collagen.set(newcollagen+dcollagennew_dt, x, y);
			} else {
				collagen.set(0, x, y);
				System.out.println("Warning - collagen (fibroblast)");
			}
					
		
			}
			
			TGFb_conc.set(LatentTGFb.get(x, y)*kact_latentTGFb/volume_media, x, y); //before latent TGFb is converted to conc, get amount (pg) to calculate active
			IL6_conc.set((IL6.get(x,y)/volume_media), x, y);
			IL1_conc.set((IL1.get(x,y)/volume_media), x, y);
			TNFa_conc.set((TNFa.get(x,y)/volume_media), x, y);
			LatentTGFb_conc.set((LatentTGFb.get(x,y)/volume_cells), x, y);
		}
	}
		
		//System.out.println("TGFB Activation");
	}
}
