%%Calculates steady state network states for all grid elements when there
%%is a horizontal linear IL1, IL6, TNFa gradient and a vertical linear TGFb
%%gradient. Shouold be in the Eclipse workspace so it has access to
%%network.met
%Tommy Athey Aug 2017
load('initialNet.mat')
tic

gridWidth = 10;
gridHeight = 10;
netSize = 91;
load network.mat
tspan = [0 1008]; %hopefully enough to reach steady state
ssnetwork = 'C:\Users\smr2we\Documents\fibrosis_feedback_on_6weeks.csv';
time = 'C:\Users\smr2we\Documents\time_steps_fibrosis_feedback_on_6weeks.csv';
states = zeros(gridWidth*gridHeight,netSize); %all networks will start at
fibrosis = 0.5;
inflam = 0.5;


for y=1:gridHeight %for every grid
    for x=1:gridWidth
        in = initialNet;
        %all inputs will be 0.25 except for the inflammatory/fibrotic
        %cytokines, just like in the model
        params{1}(1,1:11) = [0.25 y/gridHeight 0.25 x/gridWidth x/gridWidth x/gridWidth 0.25 0.25 0.25 0.25 0.25];
%         params{1}(1,1:11) = [0.25 fibrosis 0.25 inflam inflam inflam 0.25 0.25 0.25 0.25 0.25];
%         params{1}(1,12:13) = [0 0]; %turns off latent TGF-B feedback
%         params{1}(1,15:17) = [0 0 0]; %turns off IL-6 feedback
        [t,v] = ode23(@ODE,tspan,in,options,params,ODElist);
        states((y-1)*gridHeight+x,:) = v(end,:); %retrieve final network state
%         disp((gridWidth*(x-1)+y)/(gridWidth*gridHeight)); %display progress
    end
end
% figure
% plot(t,v)

% 
%     end
% end


csvwrite(time,t);
csvwrite(ssnetwork,v);
toc


